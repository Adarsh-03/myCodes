const DeleteBook = () => {
  return <div className="text-3xl text-center bg-red-300">DeleteBook</div>;
};
export default DeleteBook;
