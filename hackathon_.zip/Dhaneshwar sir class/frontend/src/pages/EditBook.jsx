const EditBook = () => {
  return <div className="text-3xl text-center bg-red-300">EditBook</div>;
};
export default EditBook;
