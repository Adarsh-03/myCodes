const UpdateBook = () => {
  return <div className="text-3xl text-center bg-red-300">UpdateBook</div>;
};
export default UpdateBook;
