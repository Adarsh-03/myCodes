const CreateBook = () => {
  return <div className="text-3xl text-center bg-red-300">CreateBook</div>;
};
export default CreateBook;
